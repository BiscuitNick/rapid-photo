"""Test Lambda Handler"""
import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("✅ Lambda function WORKS!")
    logger.info(f"Event received: {json.dumps(event)}")
    
    return {
        "statusCode": 200,
        "body": json.dumps({
            "status": "success",
            "message": "Lambda is working! psycopg2 issue needs resolution."
        })
    }
