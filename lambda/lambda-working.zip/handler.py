def lambda_handler(event, context):
    import sys
    import os
    
    # Log Python version and path
    print(f"Python version: {sys.version}")
    print(f"Python path: {sys.path}")
    
    # Try to import psycopg2
    try:
        import psycopg2
        print(f"✅ Successfully imported psycopg2: {psycopg2.__version__}")
        print(f"psycopg2 file: {psycopg2.__file__}")
        return {"statusCode": 200, "body": "Success"}
    except Exception as e:
        print(f"❌ Failed to import psycopg2: {str(e)}")
        import traceback
        traceback.print_exc()
        raise
